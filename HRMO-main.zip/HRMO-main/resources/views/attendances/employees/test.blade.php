<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>


    {{-- // Include the necessary JavaScript libraries --}}
    {{-- <script src="{{ asset('scripts/websdk.client.bundle.min.js') }}" crossorigin="*"></script> --}}
    <script src="{{ asset('assets/digitalpersona/sdk/index.js') }}" crossorigin="*"></script>
    {{-- <script src="scripts/fingerprint.sdk.min.js" crossorigin="*"></script> --}}

    <script type="">
        
    </script>

</body>

</html>
